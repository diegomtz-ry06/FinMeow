import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/generative-ai';

dotenv.config();

const genAI = GoogleGenAI({
  //apiKey: process.env.API_KEY, // make sure your .env has API_KEY=your_key
  project: 'gemini-pro',        // optional if your project is different
});

async function main() {
  const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

  const result = await model.generateContent({
    contents: [
      {
        role: 'user',
        parts: [{ text: 'Explain how AI works in a few words' }],
      },
    ],
  });

  console.log(result.text());
}

main();
