import express from "express";
import path from "path";
import { writeFile } from "fs/promises";
import { GoogleGenAI } from "@google/genai";

const app = express();
const __dirname = path.resolve();

// Configurar Gemini
const ai = new GoogleGenAI({ apiKey: "AIzaSyDtIjNXObkuYBzqKyenSNphy9JDPz83oA8" });

// Función para generar respuesta con Gemini
async function generateResponse(prompt) {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generando respuesta:", error);
        throw error;
    }
}

// Middleware para parsear JSON
app.use(express.json());

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, "public"), { index: false }));  // Deshabilitamos el index automático
app.use('/FinMeow', express.static(path.join(__dirname, "public/FinMeow"), {
    index: false,  // Deshabilitamos el index automático
    setHeaders: (res, path) => {
        if (path.endsWith('.js')) {
            res.setHeader('Content-Type', 'application/javascript');
        } else if (path.endsWith('.css')) {
            res.setHeader('Content-Type', 'text/css');
        }
    }
}));

// Ruta para la página principal - debe ir ANTES de las rutas estáticas
app.get(["/", "/index.html", "/FinMeow", "/FinMeow/"], (req, res) => {
    const indexPath = path.join(__dirname, "public/FinMeow/inicioSesion.html");
    console.log('Sirviendo página de inicio:', indexPath);
    res.sendFile(indexPath, (err) => {
        if (err) {
            console.error('Error al cargar la página:', err);
            res.status(500).send('Error al cargar la página');
        }
    });
});

// Servir archivos raíz (resultado.txt, script.js, etc.)
app.get("/resultado.txt", (req, res) => {
  res.sendFile(path.join(__dirname, "resultado.txt"));
});

// Servir archivos raíz (resultado.txt, script.js, etc.)
app.get("/estado.txt", (req, res) => {
  res.sendFile(path.join(__dirname, "estado.txt"));
});

app.get("/solucion.txt", (req, res) => {
  res.sendFile(path.join(__dirname, "solucion.txt"));
});

app.get("/script.js", (req, res) => {
  res.sendFile(path.join(__dirname, "script.js"));
});

// Endpoint para guardar la pregunta
app.post('/save-pregunta', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'No hay texto para guardar' });
    }
    
    // Forzar sobreescritura del archivo
    await writeFile('pregunta.txt', text, {
      encoding: 'utf-8',
      flag: 'w' // 'w' fuerza sobreescritura
    });
    console.log('Pregunta guardada:', text);
    res.json({ success: true });
  } catch (err) {
    console.error('Error guardando pregunta:', err);
    res.status(500).json({ error: 'Error guardando el archivo' });
  }
});

// Endpoint para procesar la pregunta con Gemini
app.post('/process-question', async (req, res) => {
  try {
    console.log('Iniciando procesamiento de pregunta...');
    
    // Leer pregunta.txt
    const fs = await import('fs/promises');
    const pregunta = await fs.readFile('pregunta.txt', 'utf-8');
    console.log('Pregunta leída:', pregunta);

    // Generar respuesta con Gemini
    console.log('Generando respuesta...');
    const respuesta = await generateResponse(pregunta);

    // Guardar en solucion.txt (forzar sobreescritura)
    await fs.writeFile('solucion.txt', respuesta, {
      encoding: 'utf-8',
      flag: 'w' // 'w' fuerza sobreescritura
    });
    console.log('Respuesta guardada en solucion.txt, contenido:', respuesta);

    res.json({ success: true });
  } catch (err) {
    console.error('Error en process-question:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Inicializar archivos al arrancar
async function initializeFiles() {
  try {
    // Crear pregunta.txt con un mensaje inicial
    await writeFile('pregunta.txt', '¡Hola! ¿En qué puedo ayudarte?', {
      encoding: 'utf-8',
      flag: 'w'
    });
    console.log('pregunta.txt inicializado con mensaje de bienvenida');

    // Generar respuesta inicial
    const respuestaInicial = await generateResponse('¡Hola! ¿En qué puedo ayudarte?');
    await writeFile('solucion.txt', respuestaInicial, {
      encoding: 'utf-8',
      flag: 'w'
    });
    console.log('solucion.txt inicializado con respuesta inicial');
  } catch (error) {
    console.error('Error inicializando archivos:', error);
  }
}

app.listen(3000, async () => {
  console.log("Servidor corriendo en http://localhost:3000/FinMeow/InicioSesion.html");
  await initializeFiles();
  console.log("Archivos inicializados");
});
