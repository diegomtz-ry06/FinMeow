// script.js
function showCredit() {
  alert("Mostrando historial crediticio...");
}

function modifyPet() {
  alert("Abriendo editor de mascota...");
}

function openSettings() {
  alert("Abriendo configuración...");
}

function goHome() {
  window.location.href = "Inicio.html";
}
