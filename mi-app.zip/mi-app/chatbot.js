import { writeFile, readFile } from "fs/promises";
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "AIzaSyDtIjNXObkuYBzqKyenSNphy9JDPz83oA8" });

async function procesarPregunta() {
    try {
        // Leer el contenido de pregunta.txt
        console.log("Leyendo pregunta.txt...");
        const prompt = await readFile("pregunta.txt", "utf-8");
        console.log("Prompt leído:", prompt);

        // Generar respuesta con Gemini
        console.log("Generando respuesta...");
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        const resultado = response.text;

        // Guardar la respuesta en solucion.txt
        await writeFile("solucion.txt", resultado, {
            encoding: "utf-8",
            flag: "w" // sobreescribir si existe
        });
        console.log("Respuesta guardada en solucion.txt");
    } catch (error) {
        console.error("Error:", error);
    }
}

// Ejecutar el proceso
procesarPregunta();
